MINMAX
Depth level for look-ahead: 1
Nodes expanded: 288

Depth level for look-ahead: 2
Nodes expanded: 83232

Time / Space complexity: O(288^d)

MINMAX w/ ALPHA-BETA PRUNING
Depth level for look-ahead: 1
Nodes expanded: 288

Depth level for look-ahead: 2
Nodes expanded: 8742

Depth level for look-ahead: 3
Nodes expanded: 84094

Time / Space complexity: O(288^3d/4)
